#include <iostream>
#include <fstream>
#include <algorithm>
#include "PLA.h"

void process_data(ifstream &data_file);

vector<Data> data_set;

int main() {

    string file = R"(C:\Users\SnowHam\CLionProjects\MLFoundation_hw1_cppver\hw1_train.dat)";
    ifstream data_file(file);

    if (data_file.is_open()) {
        process_data(data_file);
    } else {
        printf("opening file failed!\n");
    }

    // training part
    vector<int> update_set, w0_set;
    for (int i = 0; i < ITER; ++i)
    {
        pii p = PLA(data_set);
        update_set.push_back(p.first);
        w0_set.push_back(p.second);

        printf("%dth -> update_num: %d, w0: %d\n", i + 1, p.first, p.second);
    }

    sort(update_set.begin(), update_set.end());
    sort(w0_set.begin(), w0_set.end());

    printf("update median: %d\n", (update_set[ITER / 2 - 1] + update_set[ITER / 2]) / 2);
    printf("w0 median: %d\n", (w0_set[ITER / 2 - 1] + w0_set[ITER / 2]) / 2);

    return 0;
}

void process_data(ifstream &data_file)
{
    for (int i = 0; i < DATA_NUM; ++i)
    {
        Data tmp;
        tmp.input[0] = 0.0;
        for (int j = 1; j < INPUT; ++j)
        {
            data_file >> tmp.input[j];
            tmp.input[j] /= 4.0;
        }
        data_file >> tmp.output;
        data_set.push_back(tmp);
    }
}
