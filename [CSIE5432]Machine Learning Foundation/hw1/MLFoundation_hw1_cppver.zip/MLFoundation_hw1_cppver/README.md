# Mahcine Learning Foundation Fall 2020 HW1

## About

### main.cpp

使用 process_data(&data_file) 匯入資料，之後訓練 ITER(1000) 次並用 vector<int> update_set, w0_set 紀錄每次訓練的更新次數與 w_0，最後輸出兩個的中位數。

### PLA.h/PLA.cpp

- struct Data：建立一個結構叫做 Data，儲存每筆資料的 input(x), output(y)
- pii PLA(vector<Data> data_set)：先初始化 w，接著實作 PLA。當正確次數 < 5 * N(100) 時，每一次隨機選取一個資料點，若錯誤就更新，並將正確次數重設為零；若正確就將正確次數 + 1，最後回傳更新次數與 w_0。
- int sign(double x)：判斷浮點數正負，若為 0.0 則回傳 -1。
- double multiply_vector(const double *w, const double *x)：計算向量相乘。
- void update_weight(double *w, const double *x, double data_sign)：更新 w。

