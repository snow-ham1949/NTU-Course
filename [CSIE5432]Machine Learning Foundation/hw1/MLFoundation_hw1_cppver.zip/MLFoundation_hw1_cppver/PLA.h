//
// Created by SnowHam on 2020/10/4.
//

#ifndef MLFOUNDATION_HW1_CPPVER__PLA_H
#define MLFOUNDATION_HW1_CPPVER__PLA_H

#include <utility>
#include <vector>
#include <random>
#include <ctime>

using namespace std;

const int INPUT = 11;
const int ITER = 1000;
const int DATA_NUM = 100;

typedef struct Data{
    double input[INPUT];
    double output;
} Data;

typedef pair<int, int> pii;

pii PLA(vector<Data> data_set); // update_cnt, w0
int sign(double x);
double multiply_vector(const double *w, const double *x);
void update_weight(double *w, const double *x, double data_sign);

#endif //MLFOUNDATION_HW1_CPPVER__PLA_H
