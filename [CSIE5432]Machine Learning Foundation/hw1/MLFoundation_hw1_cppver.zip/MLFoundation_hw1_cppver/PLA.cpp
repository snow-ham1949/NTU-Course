//
// Created by SnowHam on 2020/10/4.
//

#include "PLA.h"

pii PLA(vector<Data> data_set)
{
    pii p; // first: update_cnt, second: w0
    p.first = p.second = 0;

    // weight array
    double w[INPUT];
    for (double & i : w)
    {
        i = 0.0;
    }

    bool finished = false;
    int correct_cnt = 0;
    while (!finished)
    {
        // randomly pick one point
        int index = rand() % 100;

        if (data_set[index].output != sign(multiply_vector(w, data_set[index].input))) {
            correct_cnt = 0;
            p.first++;
            update_weight(w, data_set[index].input, data_set[index].output);
        } else {
            correct_cnt++;
        }

        if (correct_cnt == 5 * DATA_NUM) {
            finished = true;
            p.second = w[0];
        }
    }

    return p;
}

int sign(double x) // take sign(0) as -1
{
    if (x <= 0.0) {
        return -1;
    } else {
        return 1;
    }
}

double multiply_vector(const double *w, const double *x)
{
    double ans = 0.0;

    for (int i = 0; i < INPUT; ++i)
    {
        ans += w[i] * x[i];
    }

    return ans;
}

void update_weight(double *w, const double *x, double data_sign)
{
    for (int i = 0; i < INPUT; ++i)
    {
        w[i] = w[i] + x[i] * data_sign;
    }
}
